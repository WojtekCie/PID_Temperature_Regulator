T= readtable('data.csv','PreserveVariableNames',true);
Time = T(:,1)
Temperature = T(:,2)
Time.("Timestamp (s)") = Time.("Timestamp (s)") - 1021;

T = 137.8
To = 1.175
k = 7.005

Kp = T/(k*(2*To))
Ti = min(T,8*To)
Td = 0.001